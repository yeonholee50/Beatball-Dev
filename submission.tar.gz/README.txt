Name: Yeon Lee
Game: DX_Ball Juggling Arcade Game

DX_Ball was a game that was popular in the late 90s due to both its simplicity and intriguing application. Juggling often refers to being able to handle more than one object at a time. However, because World Cup 2022 is coming up, I decided to give it a spin and make the game simpler. The purpose of Juggling ArcadeGame is simple: Never let the ball touch the ground. This was also how I practiced playing soccer at a young age. 

The controls are very simple. We have a red bar that we can control using the left and right key. Pressing:
Enter: Start the game
Backspace: Reset the game
left arrow key: makes the bar go left
right arrow key: makes the bar go right

The ball is the blue 5x5 square. However, it is not a perfect square that obeys the laws of physics! It will go in different directional vector everytime so
please be prepared. Score is calculated by adding to the score each time the magnitude of the slope at which the ball travels before it hits the rectangle. 
If it does not hit the rectangle, that magnitude of the slope will not be included in the score.

The rule of the game is very simple: Never let the ball touch the ground
