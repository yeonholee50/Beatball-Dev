/*
 * Exported with nin10kit v1.8
 * Invocation command was nin10kit --mode=3 --resize=50x37 trademarklogo trademarklogo.png 
 * Time-stamp: Monday 07/18/2022, 18:18:48
 * 
 * Image Information
 * -----------------
 * trademarklogo.png 50@37
 * 
 * All bug reports / feature requests are to be filed here https://github.com/TricksterGuy/nin10kit/issues
 */

#ifndef TRADEMARKLOGO_H
#define TRADEMARKLOGO_H

extern const unsigned short trademarklogo[1850];
#define TRADEMARKLOGO_SIZE 3700
#define TRADEMARKLOGO_LENGTH 1850
#define TRADEMARKLOGO_WIDTH 50
#define TRADEMARKLOGO_HEIGHT 37

#endif

