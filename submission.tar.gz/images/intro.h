/*
 * Exported with nin10kit v1.8
 * Invocation command was nin10kit --mode=3 --resize=240x160 intro intro.png 
 * Time-stamp: Monday 07/18/2022, 16:40:56
 * 
 * Image Information
 * -----------------
 * intro.png 240@160
 * 
 * All bug reports / feature requests are to be filed here https://github.com/TricksterGuy/nin10kit/issues
 */

#ifndef INTRO_H
#define INTRO_H

extern const unsigned short intro[38400];
#define INTRO_SIZE 76800
#define INTRO_LENGTH 38400
#define INTRO_WIDTH 240
#define INTRO_HEIGHT 160

#endif

