/*
 * Exported with nin10kit v1.8
 * Invocation command was nin10kit --mode=3 --resize=240x160 trollface trollface.png 
 * Time-stamp: Monday 07/18/2022, 17:37:15
 * 
 * Image Information
 * -----------------
 * trollface.png 240@160
 * 
 * All bug reports / feature requests are to be filed here https://github.com/TricksterGuy/nin10kit/issues
 */

#ifndef TROLLFACE_H
#define TROLLFACE_H

extern const unsigned short trollface[38400];
#define TROLLFACE_SIZE 76800
#define TROLLFACE_LENGTH 38400
#define TROLLFACE_WIDTH 240
#define TROLLFACE_HEIGHT 160

#endif

